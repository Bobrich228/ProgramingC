#include <stdlib.h>
double** sum(double** A, double** B, int n);
double** ras(double** A, double** B, int n);
double** umn(double** A, double** B, int n);
