#include <stdlib.h>
double* C(double* A, double* B, int n);
double* D(double* A, double* B, int n);
double* E(double* A, double* B, int n);
