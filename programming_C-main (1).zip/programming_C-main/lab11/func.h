#include <stdlib.h>
int sum(int n, ...);
int max(int n, ...);
int min(int n, ...);
double mid(int n, ...);
