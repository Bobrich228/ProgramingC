double per(double a, double b, double c);
double plosh(double a, double b, double c);
bool real(double a, double b, double c);

